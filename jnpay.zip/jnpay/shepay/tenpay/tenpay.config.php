<?php
$tenpay_config['mch']	= $conf['gfjk_tenpay_id'];
$tenpay_config['key']	= $conf['gfjk_tenpay_key'];
?>