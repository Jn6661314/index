<?php
class QpayMchConf
{
    const MCH_ID = $conf['gfjk_qpay_mchid'];
    const MCH_KEY = $conf['gfjk_qpay_mchkey'];
}