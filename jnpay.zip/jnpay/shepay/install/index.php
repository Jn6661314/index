<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<link rel="stylesheet" href="https://bootswatch.com/3/paper/bootstrap.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>深海易支付系统-安装向导</title>
</head>
<body background="https://ww2.sinaimg.cn/large/a15b4afegy1fpp139ax3wj200o00g073.jpg">
<div class="container" style="padding-top:55px;">
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block text-center" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading" style="background: linear-gradient(to right,#8ae68a,#5ccdde,#b221ff);"><font color="#000000">深海易支付系统</font></div>
<div class="panel-body">
<img src="http://img.98v8.cn/temp//1812/8844557953fcb5ee.jpg" alt="img"; width=99% height=99%><p><p><p><font color="#00FFFF">不</font><font color="#05FAFF">妥</font><font color="#0AF5FF">协</font><font color="#0FF0FF">，</font><font color="#14EBFF">不</font><font color="#19E6FF">逐</font><font color="#1EE1FF">流</font><font color="#23DCFF">；</font><font color="#28D7FF">随</font><font color="#2DD2FF">性</font><font color="#32CDFF">而</font><font color="#37C8FF">不</font><font color="#3CC3FF">失</font><font color="#41BEFF">个</font><font color="#46B9FF">性</font><font color="#4BB4FF">，</font><font color="#50AFFF">有</font><font color="#55AAFF">设</font><font color="#5AA5FF">计</font><font color="#5FA0FF">而</font><font color="#649BFF">不</font><font color="#6996FF">漏</font><font color="#6E91FF">痕</font><font color="#738CFF">迹</font><font color="#7887FF">；</font><font color="#7D82FF">深</font><font color="#827DFF">海</font><font color="#8778FF">易</font><font color="#8C73FF">支</font><font color="#916EFF">付</font><font color="#9669FF">，</font><font color="#9B64FF">繁</font><font color="#A060FF">华</font><font color="#A560FF">阅</font><font color="#AA60FF">尽</font><font color="#AF60FF">处</font><font color="#B460FF">，</font><font color="#B960FF">简</font><font color="#BE60FF">约</font><font color="#C360FF">不</font><font color="#C860FF">简</font><font color="#CD60FF">单</font><font color="#D260FF">！</font>
</div>
<div class="panel-footer text-center">
<a href="shyzf_install.php" class="btn btn-success">开始全新体验</a>
</div>
  </div>
  </div>
  <div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block text-center" style="float: none;">
<div class="panel panel-primary">
<div class="panel-heading" style="background: linear-gradient(to right,#8ae68a,#5ccdde,#b221ff);"><font color="#000000">深海易支付系统-版本更新内容</font></div>
<div class="panel-body">
  <?php
        include_once('../readme.html');
        ?>
  </div>
</div>
</div>
</body>
</html>