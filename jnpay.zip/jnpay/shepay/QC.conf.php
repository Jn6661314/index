<?php
//申请到的appid
$QC_config["appid"]  = 101519475;

//申请到的appkey
$QC_config["appkey"] = "62fcaec7c48acb7ac181433370131285";

//callback url
$QC_config["callback"] = 'https://jnpay.wankayanshi.xyz/user/connect.php';
?>