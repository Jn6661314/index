<?php
//深海易支付系统原创防CC模块设置框架
define('CC_Defender', 0);
?>