<?php
include("shepay/common.php");
?>
<h3>后台地址修改状态</h3>
</div>
<div class="panel-body">
<?php
$filename = $conf['houtai_filelink'];
$newname = $conf['houtai_newlink'];
 if(file_exists($filename)){
 if(rename($filename,$newname)){
     echo '啦啦啦，后台路径修改成功了～';
 }else{
   echo '额呜呜，后台路径修改失败，请重试～';
 }
  }else{
   echo '等待修改，或要修改的后台路径并不存在～';
 }
?>
	</div>
  </form>
</div>
</div>
    </div>
  </div>
