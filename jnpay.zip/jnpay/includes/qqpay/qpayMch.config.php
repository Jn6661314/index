<?php
include("../common.php");
define('MCHS_ID',$conf['qq_api_mchid']);
define('MCHS_KEY',$conf['qq_api_mchkey']);
class QpayMchConf
{
    const MCH_ID = MCHS_ID;
    const MCH_KEY = MCHS_KEY;

}
?>