<?php
/* *
 * 配置文件
 */
 
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
//商户号
$tenpay_config['mch']	= $conf['api_tenpay_id'];

//安全检验码
$tenpay_config['key']	= $conf['api_tenpay_key'];

?>